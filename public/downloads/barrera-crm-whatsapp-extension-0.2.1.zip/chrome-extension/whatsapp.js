(() => {
  if (document.getElementById("bb-crm-extension-root")) return;

  const state = {
    leads: [],
    templates: [],
    lead: null,
    selectedTemplate: null,
    imageFile: null,
    imagePreviewUrl: "",
  };

  const root = document.createElement("aside");
  root.id = "bb-crm-extension-root";
  root.innerHTML = `
    <button class="bb-launcher" type="button" aria-label="Abrir Barrera CRM" aria-expanded="false">
      <span>BB</span>
    </button>
    <section class="bb-panel" aria-label="Barrera Brokers CRM" hidden>
      <header class="bb-header">
        <div>
          <strong>Barrera Brokers</strong>
          <span>CRM conectado a WhatsApp</span>
        </div>
        <button class="bb-icon-button bb-close" type="button" aria-label="Cerrar panel">×</button>
      </header>
      <main class="bb-content">
        <form class="bb-search">
          <label for="bb-phone">Teléfono del cliente</label>
          <div class="bb-search-row">
            <input id="bb-phone" inputmode="tel" autocomplete="off" placeholder="Ej. 11 5555 5555" />
            <button type="submit">Buscar</button>
          </div>
          <p>Ingresá el número si WhatsApp muestra solamente el nombre.</p>
        </form>
        <div class="bb-status" role="status">Abrí el panel para conectar con el CRM.</div>
        <section class="bb-client" hidden></section>
        <section class="bb-templates" hidden>
          <div class="bb-section-heading">
            <h2>Plantillas</h2>
            <span class="bb-template-count"></span>
          </div>
          <div class="bb-template-list"></div>
        </section>
        <section class="bb-preview" hidden>
          <div class="bb-section-heading">
            <h2>Vista previa</h2>
            <button class="bb-text-button bb-back" type="button">Cambiar</button>
          </div>
          <textarea class="bb-message" aria-label="Mensaje de WhatsApp"></textarea>
          <div class="bb-attachments"></div>
          <div class="bb-image-picker">
            <label class="bb-image-button">
              <span>Adjuntar imagen</span>
              <small>JPG, PNG, WebP o GIF · máximo 5 MB</small>
              <input class="bb-image-input" type="file" accept="image/jpeg,image/png,image/webp,image/gif" />
            </label>
            <div class="bb-image-preview" hidden></div>
          </div>
          <button class="bb-primary bb-insert" type="button">Continuar a WhatsApp</button>
          <p class="bb-helper">WhatsApp abrirá su vista previa nativa para que confirmes el texto y la imagen antes de enviar.</p>
        </section>
      </main>
      <footer class="bb-footer">
        <a href="https://barrerabrokers.com/admin/crm" target="_blank" rel="noreferrer">Abrir CRM completo</a>
      </footer>
    </section>
  `;
  document.body.appendChild(root);

  const $ = (selector) => root.querySelector(selector);
  const launcher = $(".bb-launcher");
  const panel = $(".bb-panel");
  const phoneInput = $("#bb-phone");
  const status = $(".bb-status");
  const client = $(".bb-client");
  const templatesSection = $(".bb-templates");
  const templateList = $(".bb-template-list");
  const preview = $(".bb-preview");
  const messageInput = $(".bb-message");
  const attachments = $(".bb-attachments");
  const imageInput = $(".bb-image-input");
  const imagePreview = $(".bb-image-preview");

  const digits = (value = "") => String(value).replace(/\D/g, "");
  const comparablePhone = (value = "") => digits(value).replace(/^549/, "54").slice(-10);
  const fullName = (lead) => `${lead.firstName || ""} ${lead.lastName || ""}`.trim();

  function setStatus(message, kind = "neutral") {
    status.textContent = message;
    status.dataset.kind = kind;
    status.hidden = false;
  }

  function guessVisiblePhone() {
    const header = document.querySelector("#main header");
    const candidate = header?.textContent || "";
    const match = candidate.match(/\+?\d[\d\s().-]{7,}\d/);
    return match?.[0]?.trim() || "";
  }

  function applyVariables(value, lead) {
    const development = lead.developmentName || lead.developmentNameText || "el desarrollo";
    return String(value || "")
      .replaceAll("{{cliente_nombre}}", lead.firstName || "")
      .replaceAll("{{cliente_apellido}}", lead.lastName || "")
      .replaceAll("{{cliente_nombre_completo}}", fullName(lead))
      .replaceAll("{{cliente_email}}", lead.email || "")
      .replaceAll("{{cliente_telefono}}", `${lead.countryCode || ""} ${lead.phone || ""}`.trim())
      .replaceAll("{{desarrollo}}", development)
      .replaceAll("{{propietario_contacto}}", lead.assignedAgentName || "Barrera Brokers");
  }

  async function loadContext() {
    setStatus("Conectando con el CRM…");
    const response = await chrome.runtime.sendMessage({ type: "BB_LOAD_CONTEXT" });
    if (!response?.ok) {
      setStatus(response?.error || "No se pudo conectar con el CRM.", "error");
      return false;
    }
    if (response.leads?.__error || response.templates?.__error) {
      setStatus(response.leads?.__error || response.templates?.__error, "error");
      return false;
    }
    state.leads = response.leads?.leads || [];
    state.templates = (response.templates?.templates || []).filter((item) => item.channel === "whatsapp");
    setStatus("CRM conectado. Buscá el teléfono del chat abierto.", "success");
    return true;
  }

  function renderLead(lead) {
    if (state.lead?.id !== lead.id) clearSelectedImage();
    state.lead = lead;
    client.hidden = false;
    client.innerHTML = `
      <div class="bb-avatar">${(lead.firstName?.[0] || "")}${(lead.lastName?.[0] || "")}</div>
      <div class="bb-client-copy">
        <strong>${fullName(lead)}</strong>
        <span>${lead.developmentName || lead.developmentNameText || "Sin desarrollo asignado"}</span>
        <small>${lead.status || "Sin estado"} · ${lead.temperature || "Sin temperatura"}</small>
      </div>
    `;
    renderTemplates();
  }

  function renderTemplates() {
    preview.hidden = true;
    templatesSection.hidden = false;
    $(".bb-template-count").textContent = `${state.templates.length}`;
    if (!state.templates.length) {
      templateList.innerHTML = `<p class="bb-empty">Todavía no hay plantillas de WhatsApp en el CRM.</p>`;
      return;
    }
    templateList.innerHTML = state.templates.map((template) => `
      <button class="bb-template" type="button" data-template-id="${template.id}">
        <strong>${template.name}</strong>
        <span>${applyVariables(template.body, state.lead).slice(0, 92)}</span>
      </button>
    `).join("");
  }

  function selectTemplate(templateId) {
    const template = state.templates.find((item) => item.id === templateId);
    if (!template || !state.lead) return;
    state.selectedTemplate = template;
    templatesSection.hidden = true;
    preview.hidden = false;
    messageInput.value = applyVariables(template.body, state.lead);
    const imageUrls = template.imageUrls || [];
    attachments.innerHTML = imageUrls.map((url, index) => `
      <a href="${url}" target="_blank" rel="noreferrer">Imagen ${index + 1} · abrir para adjuntar</a>
    `).join("");
  }

  function clearSelectedImage() {
    if (state.imagePreviewUrl) URL.revokeObjectURL(state.imagePreviewUrl);
    state.imageFile = null;
    state.imagePreviewUrl = "";
    imageInput.value = "";
    imagePreview.hidden = true;
    imagePreview.innerHTML = "";
  }

  function renderSelectedImage(file) {
    clearSelectedImage();
    state.imageFile = file;
    state.imagePreviewUrl = URL.createObjectURL(file);
    imagePreview.hidden = false;
    imagePreview.innerHTML = `
      <img src="${state.imagePreviewUrl}" alt="Imagen seleccionada para WhatsApp" />
      <div>
        <strong>${file.name}</strong>
        <span>${(file.size / 1024 / 1024).toFixed(2)} MB</span>
      </div>
      <button class="bb-remove-image" type="button" aria-label="Quitar imagen">×</button>
    `;
  }

  function insertIntoWhatsApp(text) {
    const composer = document.querySelector('#main footer div[contenteditable="true"][role="textbox"]')
      || document.querySelector('#main footer div[contenteditable="true"]');
    if (!composer) throw new Error("No encontramos el campo de mensaje. Abrí una conversación e intentá nuevamente.");
    composer.focus();
    document.execCommand("selectAll", false);
    document.execCommand("insertText", false, text);
    composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
  }

  const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));

  async function findWhatsAppImageInput() {
    const findInput = () => Array.from(document.querySelectorAll('input[type="file"]')).find((input) => {
      const accept = input.getAttribute("accept") || "";
      return accept.includes("image") && !accept.includes("application");
    });

    let input = findInput();
    if (input) return input;

    const attachButton = Array.from(document.querySelectorAll("button, [role=button]")).find((element) => {
      const label = `${element.getAttribute("aria-label") || ""} ${element.getAttribute("title") || ""}`.toLowerCase();
      return label.includes("adjuntar") || label.includes("attach");
    });
    attachButton?.click();

    for (let attempt = 0; attempt < 12; attempt += 1) {
      await wait(100);
      input = findInput();
      if (input) return input;
    }
    return null;
  }

  async function attachImageToWhatsApp(file, caption) {
    const input = await findWhatsAppImageInput();
    if (!input) {
      throw new Error("No encontramos el selector de imágenes de WhatsApp. Actualizá WhatsApp Web e intentá nuevamente.");
    }

    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));

    const findCaptionBox = () => {
      const candidates = Array.from(document.querySelectorAll('div[contenteditable="true"]'))
        .filter((element) => !root.contains(element))
        .filter((element) => {
          const rect = element.getBoundingClientRect();
          const style = window.getComputedStyle(element);
          return rect.width > 120
            && rect.height > 12
            && rect.bottom > 0
            && rect.top < window.innerHeight
            && style.display !== "none"
            && style.visibility !== "hidden";
        });

      return candidates
        .map((element, index) => {
          const descriptor = [
            element.getAttribute("aria-label"),
            element.getAttribute("aria-placeholder"),
            element.getAttribute("data-placeholder"),
            element.parentElement?.getAttribute("data-placeholder"),
            element.parentElement?.textContent,
          ].filter(Boolean).join(" ").toLowerCase();
          const rect = element.getBoundingClientRect();
          let score = index;
          if (/caption|comentario|descripci[oó]n|pie de foto|mensaje/.test(descriptor)) score += 200;
          if (element.hasAttribute("data-lexical-editor")) score += 80;
          if (element.closest('[role="dialog"], [aria-modal="true"]')) score += 100;
          if (!element.closest("#main footer")) score += 40;
          if (rect.top > window.innerHeight * 0.45) score += 20;
          return { element, score };
        })
        .sort((a, b) => b.score - a.score)[0]?.element || null;
    };

    for (let attempt = 0; attempt < 60; attempt += 1) {
      await wait(100);
      const captionBox = findCaptionBox();
      if (captionBox) {
        captionBox.focus();
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(captionBox);
        range.collapse(false);
        selection?.removeAllRanges();
        selection?.addRange(range);
        document.execCommand("insertText", false, caption);
        captionBox.dispatchEvent(new InputEvent("input", {
          bubbles: true,
          inputType: "insertText",
          data: caption,
        }));
        return;
      }
    }

    throw new Error("La imagen se adjuntó, pero no encontramos el campo de descripción. Podés escribir el texto en la vista previa de WhatsApp.");
  }

  async function registerActivity(body) {
    if (!state.lead) return;
    await chrome.runtime.sendMessage({
      type: "BB_REGISTER_ACTIVITY",
      activity: {
        leadId: state.lead.id,
        type: "whatsapp",
        title: `WhatsApp con ${state.lead.firstName}`,
        body,
        scheduledAt: new Date().toISOString(),
      },
    });
  }

  launcher.addEventListener("click", async () => {
    const willOpen = panel.hidden;
    panel.hidden = !willOpen;
    launcher.setAttribute("aria-expanded", String(willOpen));
    if (!willOpen) return;
    phoneInput.value ||= guessVisiblePhone();
    await loadContext();
  });

  $(".bb-close").addEventListener("click", () => {
    panel.hidden = true;
    launcher.setAttribute("aria-expanded", "false");
  });

  $(".bb-search").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!state.leads.length && !(await loadContext())) return;
    const phone = comparablePhone(phoneInput.value);
    if (phone.length < 8) {
      setStatus("Ingresá al menos 8 números para buscar al cliente.", "error");
      return;
    }
    const lead = state.leads.find((item) => {
      const candidate = comparablePhone(`${item.countryCode || ""}${item.phone || ""}`);
      return candidate.endsWith(phone) || phone.endsWith(candidate);
    });
    if (!lead) {
      client.hidden = true;
      templatesSection.hidden = true;
      preview.hidden = true;
      setStatus("No encontramos este teléfono entre tus clientes del CRM.", "error");
      return;
    }
    status.hidden = true;
    renderLead(lead);
  });

  templateList.addEventListener("click", (event) => {
    const button = event.target.closest("[data-template-id]");
    if (button) selectTemplate(button.dataset.templateId);
  });

  $(".bb-back").addEventListener("click", renderTemplates);

  imageInput.addEventListener("change", () => {
    const file = imageInput.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setStatus("Seleccioná un archivo de imagen válido.", "error");
      clearSelectedImage();
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setStatus("La imagen supera el máximo de 5 MB.", "error");
      clearSelectedImage();
      return;
    }
    status.hidden = true;
    renderSelectedImage(file);
  });

  imagePreview.addEventListener("click", (event) => {
    if (event.target.closest(".bb-remove-image")) clearSelectedImage();
  });

  $(".bb-insert").addEventListener("click", async () => {
    const button = $(".bb-insert");
    try {
      button.disabled = true;
      button.textContent = state.imageFile ? "Preparando imagen…" : "Preparando mensaje…";
      const message = messageInput.value.trim();
      if (state.imageFile) {
        await attachImageToWhatsApp(state.imageFile, message);
      } else {
        insertIntoWhatsApp(message);
      }
      await registerActivity([
        message,
        state.imageFile ? `Imagen adjunta: ${state.imageFile.name}` : "",
      ].filter(Boolean).join("\n\n"));
      button.textContent = "Vista previa lista";
      setTimeout(() => {
        button.disabled = false;
        button.textContent = "Continuar a WhatsApp";
      }, 1800);
    } catch (error) {
      button.disabled = false;
      button.textContent = "Continuar a WhatsApp";
      setStatus(error.message, "error");
    }
  });
})();
