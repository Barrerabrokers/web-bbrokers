const CRM_ORIGIN = "https://barrerabrokers.com";

async function getCrmTab(openWhenMissing = true) {
  const tabs = await chrome.tabs.query({ url: `${CRM_ORIGIN}/*` });
  if (tabs[0]?.id) return tabs[0];
  if (!openWhenMissing) return null;
  return chrome.tabs.create({ url: `${CRM_ORIGIN}/admin/crm?extension=1`, active: true });
}

async function callCrm(path, options = {}) {
  const tab = await getCrmTab(true);
  if (!tab?.id) throw new Error("No se pudo abrir el CRM.");

  try {
    return await chrome.tabs.sendMessage(tab.id, {
      type: "BB_CRM_FETCH",
      path,
      options,
    });
  } catch {
    await chrome.tabs.update(tab.id, { active: true });
    throw new Error("Iniciá sesión en el CRM y volvé a WhatsApp Web.");
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "BB_LOAD_CONTEXT") {
    Promise.all([
      callCrm("/api/crm/leads"),
      callCrm("/api/crm/templates"),
    ])
      .then(([leads, templates]) => sendResponse({ ok: true, leads, templates }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "BB_REGISTER_ACTIVITY") {
    callCrm("/api/crm/activities", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(message.activity),
    })
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "BB_CREATE_LEAD") {
    callCrm("/api/crm/leads", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...message.lead, source: "WhatsApp" }),
    })
      .then((result) => {
        if (result?.__error) throw new Error(result.__error);
        sendResponse({ ok: true, result });
      })
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
});
