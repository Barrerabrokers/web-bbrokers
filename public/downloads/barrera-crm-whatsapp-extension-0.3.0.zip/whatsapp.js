(() => {
  if (document.getElementById("bb-crm-extension-root")) return;

  const state = {
    leads: [],
    templates: [],
    lead: null,
    selectedTemplate: null,
    imageFile: null,
    imagePreviewUrl: "",
    contactTabs: [],
    activeTabId: "all",
  };

  const DEFAULT_CONTACT_TABS = [
    { id: "all", name: "Todos", status: "" },
    { id: "new", name: "Nuevos", status: "NEW" },
    { id: "progress", name: "En curso", status: "En curso" },
    { id: "unanswered", name: "No contesta", status: "No Contesta" },
    { id: "closed", name: "Cerrados", status: "Vendido" },
  ];

  const root = document.createElement("aside");
  root.id = "bb-crm-extension-root";
  root.innerHTML = `
    <nav class="bb-topbar" aria-label="Listas de contactos del CRM">
      <button class="bb-topbar-brand" type="button" aria-label="Abrir Barrera CRM">BB</button>
      <div class="bb-contact-tabs" role="tablist" aria-label="Contactos por estado"></div>
      <button class="bb-edit-tabs" type="button" aria-label="Editar pestañas">Editar pestañas</button>
    </nav>
    <section class="bb-tabs-editor" aria-label="Editar pestañas" hidden>
      <header>
        <div><strong>Organizar contactos</strong><span>Creá pestañas según el estado del lead.</span></div>
        <button class="bb-editor-close" type="button" aria-label="Cerrar">×</button>
      </header>
      <div class="bb-tabs-editor-list"></div>
      <footer>
        <button class="bb-add-tab" type="button">＋ Añadir pestaña</button>
        <button class="bb-save-tabs" type="button">Guardar cambios</button>
      </footer>
    </section>
    <button class="bb-launcher" type="button" aria-label="Abrir Barrera CRM" aria-expanded="false">
      <span>BB</span>
    </button>
    <section class="bb-panel" aria-label="Barrera Brokers CRM" hidden>
      <header class="bb-header">
        <div>
          <strong>Barrera Brokers</strong>
          <span>CRM conectado a WhatsApp</span>
        </div>
        <button class="bb-icon-button bb-close" type="button" aria-label="Cerrar panel">×</button>
      </header>
      <main class="bb-content">
        <form class="bb-search">
          <label for="bb-phone">Buscar cliente</label>
          <div class="bb-search-row">
            <input id="bb-phone" autocomplete="off" placeholder="Nombre, teléfono o email" />
            <button type="submit">Buscar</button>
          </div>
          <p>Buscá por nombre, apellido, teléfono o correo electrónico.</p>
        </form>
        <div class="bb-status" role="status">Abrí el panel para conectar con el CRM.</div>
        <section class="bb-results" hidden></section>
        <section class="bb-client" hidden></section>
        <section class="bb-lead-context" hidden></section>
        <section class="bb-templates" hidden>
          <div class="bb-section-heading">
            <h2>Elegí cómo escribir</h2>
            <span class="bb-template-count"></span>
          </div>
          <button class="bb-new-message" type="button">
            <strong>＋ Nuevo mensaje</strong>
            <span>Escribí un texto desde cero</span>
          </button>
          <div class="bb-template-label">Plantillas</div>
          <div class="bb-template-list"></div>
        </section>
        <section class="bb-preview" hidden>
          <div class="bb-section-heading">
            <h2>Vista previa</h2>
            <button class="bb-text-button bb-back" type="button">Cambiar</button>
          </div>
          <textarea class="bb-message" aria-label="Mensaje de WhatsApp" placeholder="Escribí el mensaje para el cliente…"></textarea>
          <div class="bb-attachments"></div>
          <div class="bb-image-picker">
            <label class="bb-image-button">
              <span>Adjuntar imagen</span>
              <small>JPG, PNG, WebP o GIF · máximo 5 MB</small>
              <input class="bb-image-input" type="file" accept="image/jpeg,image/png,image/webp,image/gif" />
            </label>
            <div class="bb-image-preview" hidden></div>
          </div>
          <button class="bb-primary bb-insert" type="button">Continuar a WhatsApp</button>
          <p class="bb-helper">WhatsApp abrirá su vista previa nativa para que confirmes el texto y la imagen antes de enviar.</p>
        </section>
      </main>
      <footer class="bb-footer">
        <a href="https://barrerabrokers.com/admin/crm" target="_blank" rel="noreferrer">Abrir CRM completo</a>
      </footer>
    </section>
  `;
  document.body.appendChild(root);
  document.documentElement.classList.add("bb-crm-topbar-active");

  const $ = (selector) => root.querySelector(selector);
  const launcher = $(".bb-launcher");
  const contactTabs = $(".bb-contact-tabs");
  const tabsEditor = $(".bb-tabs-editor");
  const tabsEditorList = $(".bb-tabs-editor-list");
  const panel = $(".bb-panel");
  const phoneInput = $("#bb-phone");
  const status = $(".bb-status");
  const results = $(".bb-results");
  const client = $(".bb-client");
  const leadContext = $(".bb-lead-context");
  const templatesSection = $(".bb-templates");
  const templateList = $(".bb-template-list");
  const preview = $(".bb-preview");
  const messageInput = $(".bb-message");
  const attachments = $(".bb-attachments");
  const imageInput = $(".bb-image-input");
  const imagePreview = $(".bb-image-preview");

  const digits = (value = "") => String(value).replace(/\D/g, "");
  const comparablePhone = (value = "") => digits(value).replace(/^549/, "54").slice(-10);
  const fullName = (lead) => `${lead.firstName || ""} ${lead.lastName || ""}`.trim();
  const normalizeText = (value = "") => String(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  const escapeHtml = (value = "") => String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;",
  })[character]);

  function whatsAppPhone(lead) {
    let phone = digits(`${lead.countryCode || ""}${lead.phone || ""}`);
    // WhatsApp exige el 9 entre el código de Argentina y el número móvil.
    if (phone.startsWith("54") && !phone.startsWith("549")) phone = `549${phone.slice(2)}`;
    return phone;
  }

  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("No pudimos preparar la imagen para cambiar de conversación."));
      reader.readAsDataURL(file);
    });
  }

  function dataUrlToFile(dataUrl, name, type) {
    const [metadata, encoded] = dataUrl.split(",");
    const mime = type || metadata.match(/data:([^;]+)/)?.[1] || "image/jpeg";
    const bytes = atob(encoded);
    const buffer = new Uint8Array(bytes.length);
    for (let index = 0; index < bytes.length; index += 1) buffer[index] = bytes.charCodeAt(index);
    return new File([buffer], name || "imagen.jpg", { type: mime });
  }

  function setStatus(message, kind = "neutral") {
    status.textContent = message;
    status.dataset.kind = kind;
    status.hidden = false;
  }

  function leadsForTab(tab) {
    if (!tab?.status) return state.leads;
    const expected = normalizeText(tab.status);
    return state.leads.filter((lead) => normalizeText(lead.status || lead.leadStatus || lead.lead_status) === expected);
  }

  function renderContactTabs() {
    contactTabs.innerHTML = state.contactTabs.map((tab) => {
      const count = leadsForTab(tab).length;
      const selected = tab.id === state.activeTabId;
      return `<button class="bb-contact-tab" type="button" role="tab" aria-selected="${selected}" data-tab-id="${escapeHtml(tab.id)}">
        <span>${escapeHtml(tab.name)}</span><small>${count}</small>
      </button>`;
    }).join("");
  }

  async function loadContactTabs() {
    const stored = await chrome.storage.local.get("bbContactTabs");
    state.contactTabs = Array.isArray(stored.bbContactTabs) && stored.bbContactTabs.length
      ? stored.bbContactTabs
      : DEFAULT_CONTACT_TABS;
    renderContactTabs();
  }

  function availableStatuses() {
    return [...new Set(state.leads.map((lead) => lead.status || lead.leadStatus || lead.lead_status).filter(Boolean))]
      .sort((a, b) => String(a).localeCompare(String(b), "es"));
  }

  function renderTabsEditor() {
    const statuses = [...new Set([
      ...availableStatuses(),
      ...state.contactTabs.map((tab) => tab.status).filter(Boolean),
    ])].sort((a, b) => String(a).localeCompare(String(b), "es"));
    tabsEditorList.innerHTML = state.contactTabs.map((tab) => `
      <div class="bb-tab-editor-row" data-editor-tab-id="${escapeHtml(tab.id)}">
        <input class="bb-tab-name" value="${escapeHtml(tab.name)}" aria-label="Nombre de la pestaña" maxlength="24" />
        <select class="bb-tab-status" aria-label="Estado del lead">
          <option value="" ${!tab.status ? "selected" : ""}>Todos los estados</option>
          ${statuses.map((statusValue) => `<option value="${escapeHtml(statusValue)}" ${statusValue === tab.status ? "selected" : ""}>${escapeHtml(statusValue)}</option>`).join("")}
        </select>
        <button class="bb-delete-tab" type="button" aria-label="Eliminar pestaña">×</button>
      </div>
    `).join("");
  }

  function guessVisiblePhone() {
    const header = document.querySelector("#main header");
    const candidate = header?.textContent || "";
    const match = candidate.match(/\+?\d[\d\s().-]{7,}\d/);
    return match?.[0]?.trim() || "";
  }

  function applyVariables(value, lead) {
    const development = lead.developmentName || lead.developmentNameText || "el desarrollo";
    return String(value || "")
      .replaceAll("{{cliente_nombre}}", lead.firstName || "")
      .replaceAll("{{cliente_apellido}}", lead.lastName || "")
      .replaceAll("{{cliente_nombre_completo}}", fullName(lead))
      .replaceAll("{{cliente_email}}", lead.email || "")
      .replaceAll("{{cliente_telefono}}", `${lead.countryCode || ""} ${lead.phone || ""}`.trim())
      .replaceAll("{{desarrollo}}", development)
      .replaceAll("{{propietario_contacto}}", lead.assignedAgentName || "Barrera Brokers");
  }

  async function loadContext() {
    setStatus("Conectando con el CRM…");
    const response = await chrome.runtime.sendMessage({ type: "BB_LOAD_CONTEXT" });
    if (!response?.ok) {
      setStatus(response?.error || "No se pudo conectar con el CRM.", "error");
      return false;
    }
    if (response.leads?.__error || response.templates?.__error) {
      setStatus(response.leads?.__error || response.templates?.__error, "error");
      return false;
    }
    state.leads = response.leads?.leads || [];
    state.templates = (response.templates?.templates || []).filter((item) => item.channel === "whatsapp");
    setStatus("CRM conectado. Buscá un cliente por nombre, teléfono o email.", "success");
    renderContactTabs();
    return true;
  }

  function renderLead(lead) {
    if (state.lead?.id !== lead.id) clearSelectedImage();
    state.lead = lead;
    results.hidden = true;
    client.hidden = false;
    leadContext.hidden = false;
    const development = lead.developmentName
      || lead.developmentNameText
      || lead.development_name
      || lead.development_name_text
      || "Sin emprendimiento asignado";
    const leadStatus = lead.status || lead.leadStatus || lead.lead_status || "Sin estado";
    client.innerHTML = `
      <div class="bb-avatar">${(lead.firstName?.[0] || "")}${(lead.lastName?.[0] || "")}</div>
      <div class="bb-client-copy">
        <strong>${escapeHtml(fullName(lead))}</strong>
        <span class="bb-client-email">${escapeHtml(lead.email || `${lead.countryCode || ""} ${lead.phone || ""}`.trim())}</span>
      </div>
    `;
    leadContext.innerHTML = `
      <div class="bb-context-item">
        <span>Emprendimiento consultado</span>
        <strong>${escapeHtml(development)}</strong>
      </div>
      <div class="bb-context-item">
        <span>Estado del lead</span>
        <strong class="bb-status-badge">${escapeHtml(leadStatus)}</strong>
      </div>
    `;
    renderTemplates();
  }

  function renderSearchResults(matches) {
    client.hidden = true;
    leadContext.hidden = true;
    templatesSection.hidden = true;
    preview.hidden = true;
    results.hidden = false;
    results.innerHTML = `
      <div class="bb-results-heading">${matches.length} clientes encontrados</div>
      ${matches.slice(0, 20).map((lead) => `
        <button type="button" class="bb-result" data-lead-id="${escapeHtml(lead.id)}">
          <strong>${escapeHtml(fullName(lead) || "Cliente sin nombre")}</strong>
          <span>${escapeHtml(lead.email || `${lead.countryCode || ""} ${lead.phone || ""}`.trim())}</span>
          <small>${escapeHtml(lead.developmentName || lead.developmentNameText || "Sin emprendimiento")} · ${escapeHtml(lead.status || "Sin estado")}</small>
        </button>
      `).join("")}
    `;
  }

  function renderTemplates() {
    preview.hidden = true;
    templatesSection.hidden = false;
    $(".bb-template-count").textContent = `${state.templates.length}`;
    if (!state.templates.length) {
      templateList.innerHTML = `<p class="bb-empty">Todavía no hay plantillas de WhatsApp en el CRM.</p>`;
      return;
    }
    templateList.innerHTML = state.templates.map((template) => `
      <button class="bb-template" type="button" data-template-id="${template.id}">
        <strong>${template.name}</strong>
        <span>${applyVariables(template.body, state.lead).slice(0, 92)}</span>
      </button>
    `).join("");
  }

  function selectTemplate(templateId) {
    const template = state.templates.find((item) => item.id === templateId);
    if (!template || !state.lead) return;
    state.selectedTemplate = template;
    templatesSection.hidden = true;
    preview.hidden = false;
    messageInput.value = applyVariables(template.body, state.lead);
    const imageUrls = template.imageUrls || [];
    attachments.innerHTML = imageUrls.map((url, index) => `
      <a href="${url}" target="_blank" rel="noreferrer">Imagen ${index + 1} · abrir para adjuntar</a>
    `).join("");
  }

  function createNewMessage() {
    state.selectedTemplate = null;
    templatesSection.hidden = true;
    preview.hidden = false;
    messageInput.value = "";
    attachments.innerHTML = "";
    clearSelectedImage();
    messageInput.focus();
  }

  function clearSelectedImage() {
    if (state.imagePreviewUrl) URL.revokeObjectURL(state.imagePreviewUrl);
    state.imageFile = null;
    state.imagePreviewUrl = "";
    imageInput.value = "";
    imagePreview.hidden = true;
    imagePreview.innerHTML = "";
  }

  function renderSelectedImage(file) {
    clearSelectedImage();
    state.imageFile = file;
    state.imagePreviewUrl = URL.createObjectURL(file);
    imagePreview.hidden = false;
    imagePreview.innerHTML = `
      <img src="${state.imagePreviewUrl}" alt="Imagen seleccionada para WhatsApp" />
      <div>
        <strong>${file.name}</strong>
        <span>${(file.size / 1024 / 1024).toFixed(2)} MB</span>
      </div>
      <button class="bb-remove-image" type="button" aria-label="Quitar imagen">×</button>
    `;
  }

  function insertIntoWhatsApp(text) {
    const composer = document.querySelector('#main footer div[contenteditable="true"][role="textbox"]')
      || document.querySelector('#main footer div[contenteditable="true"]');
    if (!composer) throw new Error("No encontramos el campo de mensaje. Abrí una conversación e intentá nuevamente.");
    composer.focus();
    document.execCommand("selectAll", false);
    document.execCommand("insertText", false, text);
  }

  const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));

  async function findWhatsAppImageInput() {
    const describe = (element) => [
      element.getAttribute("aria-label"),
      element.getAttribute("title"),
      element.getAttribute("data-testid"),
      element.getAttribute("data-icon"),
      element.textContent,
    ].filter(Boolean).join(" ").toLowerCase();

    const isStickerControl = (element) => {
      const descriptor = describe(element.closest("label, button, [role=button], li") || element);
      return /sticker|calcoman[ií]a|pegatina/.test(descriptor);
    };

    const rankMediaInput = (input) => {
      const accept = (input.getAttribute("accept") || "").toLowerCase();
      if (!accept.includes("image") || accept.includes("application") || isStickerControl(input)) return -1;

      // Algunas versiones de WhatsApp usan solamente `image/*` para "Fotos y
      // videos". Debe seguir siendo un candidato válido; los indicios de video
      // y selección múltiple solo sirven para darle prioridad.
      let score = 20;
      if (accept.includes("video")) score += 300;
      if (input.multiple || input.hasAttribute("multiple")) score += 120;
      if (/jpe?g|png|gif/.test(accept)) score += 60;
      if (accept.trim() === "image/*") score += 10;
      if (accept.includes("webp") && !accept.includes("video")) score -= 10;
      return score;
    };

    const findInput = (inputs = Array.from(document.querySelectorAll('input[type="file"]'))) => inputs
      .map((input) => ({ input, score: rankMediaInput(input) }))
      .filter(({ score }) => score >= 0)
      .sort((a, b) => b.score - a.score)[0]?.input || null;

    const attachButton = Array.from(document.querySelectorAll("button, [role=button]")).find((element) => {
      const label = describe(element);
      return label.includes("adjuntar") || label.includes("attach");
    });
    if (!attachButton) return findInput();

    attachButton.click();

    let mediaOption = null;
    for (let attempt = 0; attempt < 15; attempt += 1) {
      await wait(100);
      mediaOption = Array.from(document.querySelectorAll('button, [role="button"], li, label'))
        .filter((element) => !root.contains(element))
        .find((element) => /fotos? y videos?|photos? (?:&|and) videos?|im[aá]genes? y videos?|galer[ií]a/.test(describe(element)));
      if (mediaOption) break;
    }

    if (mediaOption) {
      const nestedInput = mediaOption.querySelector('input[type="file"]');
      if (nestedInput && rankMediaInput(nestedInput) >= 0) return nestedInput;
      mediaOption.click();
    }

    for (let attempt = 0; attempt < 20; attempt += 1) {
      await wait(100);
      const input = findInput();
      if (input) return input;
    }
    return null;
  }

  async function attachImageToWhatsApp(file, caption) {
    const input = await findWhatsAppImageInput();
    if (!input) {
      throw new Error("No encontramos el selector de imágenes de WhatsApp. Actualizá WhatsApp Web e intentá nuevamente.");
    }

    const editorsBeforeAttachment = new Set(Array.from(document.querySelectorAll(
      '[contenteditable]:not([contenteditable="false"]), [role="textbox"], [data-lexical-editor="true"]'
    )));

    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));

    const findCaptionBox = () => {
      const candidates = Array.from(document.querySelectorAll(
        '[contenteditable]:not([contenteditable="false"]), [role="textbox"], [data-lexical-editor="true"]'
      ))
        .filter((element) => !root.contains(element))
        .filter((element) => {
          const rect = element.getBoundingClientRect();
          const style = window.getComputedStyle(element);
          return rect.width > 20
            && rect.height > 8
            && rect.bottom > 0
            && rect.top < window.innerHeight
            && style.display !== "none"
            && style.visibility !== "hidden"
            && !element.closest('[aria-hidden="true"]');
        });

      return candidates
        .map((element, index) => {
          const descriptor = [
            element.getAttribute("aria-label"),
            element.getAttribute("aria-placeholder"),
            element.getAttribute("data-placeholder"),
            element.parentElement?.getAttribute("data-placeholder"),
            element.closest('[role="dialog"], [aria-modal="true"]')?.textContent,
            element.parentElement?.textContent,
          ].filter(Boolean).join(" ").toLowerCase();
          const rect = element.getBoundingClientRect();
          let score = index;
          if (!editorsBeforeAttachment.has(element)) score += 300;
          if (/caption|comentario|descripci[oó]n|pie de foto|mensaje/.test(descriptor)) score += 200;
          if (element.hasAttribute("data-lexical-editor")) score += 80;
          if (element.closest('[role="dialog"], [aria-modal="true"]')) score += 100;
          if (element.closest("#main footer") && !element.closest('[role="dialog"], [aria-modal="true"]')) score -= 250;
          else score += 40;
          if (rect.top > window.innerHeight * 0.45) score += 20;
          return { element, score };
        })
        .filter(({ score }) => score > 0)
        .sort((a, b) => b.score - a.score)[0]?.element || null;
    };

    for (let attempt = 0; attempt < 60; attempt += 1) {
      await wait(100);
      const captionBox = findCaptionBox();
      if (captionBox) {
        captionBox.focus();
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(captionBox);
        range.collapse(false);
        selection?.removeAllRanges();
        selection?.addRange(range);
        document.execCommand("selectAll", false);
        document.execCommand("insertText", false, caption);
        return;
      }
    }

    throw new Error("La imagen se adjuntó, pero no encontramos el campo de descripción. Podés escribir el texto en la vista previa de WhatsApp.");
  }

  async function registerActivity(body) {
    if (!state.lead) return;
    await chrome.runtime.sendMessage({
      type: "BB_REGISTER_ACTIVITY",
      activity: {
        leadId: state.lead.id,
        type: "whatsapp",
        title: `WhatsApp con ${state.lead.firstName}`,
        body,
        scheduledAt: new Date().toISOString(),
      },
    });
  }

  async function continueInClientChat(message) {
    if (!state.lead) throw new Error("Seleccioná primero un cliente del CRM.");
    const phone = whatsAppPhone(state.lead);
    if (phone.length < 10) throw new Error("El cliente no tiene un teléfono válido para WhatsApp.");

    const pending = {
      createdAt: Date.now(),
      phone,
      message,
      leadId: state.lead.id,
      leadName: state.lead.firstName || "cliente",
      image: state.imageFile ? {
        dataUrl: await fileToDataUrl(state.imageFile),
        name: state.imageFile.name,
        type: state.imageFile.type,
      } : null,
    };
    await chrome.storage.local.set({ bbPendingWhatsAppSend: pending });
    window.location.assign(`https://web.whatsapp.com/send?phone=${encodeURIComponent(phone)}`);
  }

  async function resumePendingSend() {
    const { bbPendingWhatsAppSend: pending } = await chrome.storage.local.get("bbPendingWhatsAppSend");
    if (!pending || Date.now() - pending.createdAt > 2 * 60 * 1000) {
      if (pending) await chrome.storage.local.remove("bbPendingWhatsAppSend");
      return;
    }

    const expectedPhone = digits(pending.phone);
    const currentPhone = digits(new URL(window.location.href).searchParams.get("phone") || "");
    if (currentPhone && currentPhone !== expectedPhone) return;

    await chrome.storage.local.remove("bbPendingWhatsAppSend");
    try {
      // Espera a que WhatsApp termine de abrir la conversación indicada.
      for (let attempt = 0; attempt < 80; attempt += 1) {
        if (document.querySelector("#main")) break;
        await wait(250);
      }

      if (pending.image) {
        const file = dataUrlToFile(pending.image.dataUrl, pending.image.name, pending.image.type);
        await attachImageToWhatsApp(file, pending.message || "");
      } else {
        insertIntoWhatsApp(pending.message || "");
      }

      await chrome.runtime.sendMessage({
        type: "BB_REGISTER_ACTIVITY",
        activity: {
          leadId: pending.leadId,
          type: "whatsapp",
          title: `WhatsApp con ${pending.leadName}`,
          body: [pending.message, pending.image ? `Imagen adjunta: ${pending.image.name}` : ""].filter(Boolean).join("\n\n"),
          scheduledAt: new Date().toISOString(),
        },
      });
    } catch (error) {
      panel.hidden = false;
      launcher.setAttribute("aria-expanded", "true");
      setStatus(error.message, "error");
    }
  }

  launcher.addEventListener("click", async () => {
    const willOpen = panel.hidden;
    panel.hidden = !willOpen;
    launcher.setAttribute("aria-expanded", String(willOpen));
    if (!willOpen) return;
    phoneInput.value ||= guessVisiblePhone();
    await loadContext();
  });

  $(".bb-topbar-brand").addEventListener("click", () => launcher.click());

  contactTabs.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-tab-id]");
    if (!button) return;
    if (!state.leads.length && !(await loadContext())) return;
    const tab = state.contactTabs.find((item) => item.id === button.dataset.tabId);
    if (!tab) return;
    state.activeTabId = tab.id;
    renderContactTabs();
    panel.hidden = false;
    launcher.setAttribute("aria-expanded", "true");
    status.hidden = true;
    renderSearchResults(leadsForTab(tab));
  });

  $(".bb-edit-tabs").addEventListener("click", async () => {
    if (!state.leads.length) await loadContext();
    renderTabsEditor();
    tabsEditor.hidden = false;
  });

  $(".bb-editor-close").addEventListener("click", () => { tabsEditor.hidden = true; });

  $(".bb-add-tab").addEventListener("click", () => {
    state.contactTabs.push({ id: `custom-${Date.now()}`, name: "Nueva lista", status: "" });
    renderTabsEditor();
    tabsEditorList.querySelector(".bb-tab-editor-row:last-child .bb-tab-name")?.focus();
  });

  tabsEditorList.addEventListener("click", (event) => {
    const button = event.target.closest(".bb-delete-tab");
    if (!button || state.contactTabs.length === 1) return;
    const row = button.closest("[data-editor-tab-id]");
    state.contactTabs = state.contactTabs.filter((tab) => tab.id !== row.dataset.editorTabId);
    if (!state.contactTabs.some((tab) => tab.id === state.activeTabId)) state.activeTabId = state.contactTabs[0].id;
    renderTabsEditor();
  });

  $(".bb-save-tabs").addEventListener("click", async () => {
    const rows = Array.from(tabsEditorList.querySelectorAll("[data-editor-tab-id]"));
    state.contactTabs = rows.map((row, index) => ({
      id: row.dataset.editorTabId || `custom-${Date.now()}-${index}`,
      name: row.querySelector(".bb-tab-name").value.trim() || `Lista ${index + 1}`,
      status: row.querySelector(".bb-tab-status").value,
    }));
    await chrome.storage.local.set({ bbContactTabs: state.contactTabs });
    renderContactTabs();
    tabsEditor.hidden = true;
  });

  $(".bb-close").addEventListener("click", () => {
    panel.hidden = true;
    launcher.setAttribute("aria-expanded", "false");
  });

  $(".bb-search").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!state.leads.length && !(await loadContext())) return;
    const query = normalizeText(phoneInput.value);
    const phone = comparablePhone(query);
    if (query.length < 2) {
      setStatus("Ingresá al menos 2 caracteres para buscar al cliente.", "error");
      return;
    }
    const matches = state.leads.filter((item) => {
      const candidate = comparablePhone(`${item.countryCode || ""}${item.phone || ""}`);
      const name = normalizeText(fullName(item));
      const email = normalizeText(item.email);
      const phoneMatch = phone.length >= 4 && (candidate.endsWith(phone) || phone.endsWith(candidate));
      return phoneMatch || name.includes(query) || email.includes(query);
    });
    if (!matches.length) {
      results.hidden = true;
      client.hidden = true;
      leadContext.hidden = true;
      templatesSection.hidden = true;
      preview.hidden = true;
      setStatus("No encontramos clientes con ese nombre, teléfono o email.", "error");
      return;
    }
    status.hidden = true;
    if (matches.length === 1) renderLead(matches[0]);
    else renderSearchResults(matches);
  });

  results.addEventListener("click", (event) => {
    const button = event.target.closest("[data-lead-id]");
    if (!button) return;
    const lead = state.leads.find((item) => String(item.id) === button.dataset.leadId);
    if (lead) renderLead(lead);
  });

  templateList.addEventListener("click", (event) => {
    const button = event.target.closest("[data-template-id]");
    if (button) selectTemplate(button.dataset.templateId);
  });

  $(".bb-new-message").addEventListener("click", createNewMessage);

  $(".bb-back").addEventListener("click", renderTemplates);

  imageInput.addEventListener("change", () => {
    const file = imageInput.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setStatus("Seleccioná un archivo de imagen válido.", "error");
      clearSelectedImage();
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setStatus("La imagen supera el máximo de 5 MB.", "error");
      clearSelectedImage();
      return;
    }
    status.hidden = true;
    renderSelectedImage(file);
  });

  imagePreview.addEventListener("click", (event) => {
    if (event.target.closest(".bb-remove-image")) clearSelectedImage();
  });

  $(".bb-insert").addEventListener("click", async () => {
    const button = $(".bb-insert");
    try {
      button.disabled = true;
      button.textContent = "Abriendo chat del cliente…";
      const message = messageInput.value.trim();
      if (!message && !state.imageFile) {
        throw new Error("Escribí un mensaje o adjuntá una imagen antes de continuar.");
      }
      await continueInClientChat(message);
    } catch (error) {
      button.disabled = false;
      button.textContent = "Continuar a WhatsApp";
      setStatus(error.message, "error");
    }
  });

  loadContactTabs();
  resumePendingSend();
})();
