chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "BB_CRM_FETCH") return false;

  fetch(message.path, {
    ...message.options,
    credentials: "include",
  })
    .then(async (response) => {
      const data = await response.json().catch(() => null);
      if (!response.ok) {
        throw new Error(data?.error || `El CRM respondió con estado ${response.status}.`);
      }
      sendResponse(data);
    })
    .catch((error) => sendResponse({ __error: error.message }));

  return true;
});
